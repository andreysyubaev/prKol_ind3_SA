﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private ArrayList results;
        public Form1()
        {
            InitializeComponent();
            results = new ArrayList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (WhiteSpace(x1textBox.Text))
                MessageBox.Show("введите X первого вектора");
            else if (WhiteSpace(y1textBox.Text))
                MessageBox.Show("введите Y первого вектора");
            else if (WhiteSpace(z1textBox.Text))
                MessageBox.Show("введите Z первого вектора");
            else if (WhiteSpace(x2textBox.Text))
                MessageBox.Show("введите X второго вектора");
            else if (WhiteSpace(y2textBox.Text))
                MessageBox.Show("введите Y второго вектора");
            else if (WhiteSpace(z2textBox.Text))
                MessageBox.Show("введите Z второго вектора");
            else if (Letter(x1textBox.Text))
                MessageBox.Show("не используйте буквы в X первого вектора");
            else if (Letter(y1textBox.Text))
                MessageBox.Show("не используйте буквы в Y первого вектора");
            else if (Letter(z1textBox.Text))
                MessageBox.Show("не используйте буквы в Z первого вектора");
            else if (Letter(x2textBox.Text))
                MessageBox.Show("не используйте буквы в X второго вектора");
            else if (Letter(y2textBox.Text))
                MessageBox.Show("не используйте буквы в Y второго вектора");
            else if (Letter(z2textBox.Text))
                MessageBox.Show("не используйте буквы в Z второго вектора");
            else
            {
                double x1 = double.Parse(x1textBox.Text);
                double y1 = double.Parse(y1textBox.Text);
                double z1 = double.Parse(z1textBox.Text);
                double x2 = double.Parse(x2textBox.Text);
                double y2 = double.Parse(y2textBox.Text);
                double z2 = double.Parse(z2textBox.Text);

                Vector vector1 = new Vector(x1, y1, z1);
                Vector vector2 = new Vector(x2, y2, z2);

                if (radioButton1.Checked)
                {
                    Vector result = vector1.Add(vector2);
                    results.Add($"Сумма: {result}");
                }
                else if (radioButton2.Checked)
                {
                    Vector result = vector1.Subtract(vector2);
                    results.Add($"Разность: {result}");
                }
                else if (radioButton3.Checked)
                {
                    double dotProduct = vector1.DotProduct(vector2);
                    results.Add($"Скалярное произведение: {dotProduct}");
                }
                else if (radioButton4.Checked)
                {
                    double magnitude = vector1.Magnitude();
                    results.Add($"Длина вектора 1: {magnitude}");
                }
                else if (radioButton5.Checked)
                {
                    double cosine = vector1.Cos(vector2);
                    results.Add($"Косинус угла: {cosine}");
                }
                else
                {
                    MessageBox.Show("выберите способ вычисления");
                }

                DisplayResults();
            }
        }
        private void DisplayResults()
        {
            listBox1.Items.Clear();
            foreach (string result in results)
            {
                listBox1.Items.Add(result);
            }
        }

        private bool WhiteSpace(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return true;
            return false;
        }

        private bool Letter(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (char.IsLetter(text[i]))
                    return true;
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
